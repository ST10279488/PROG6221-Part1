﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;

namespace PartOne
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var recipe = new Recipe();
            while (true)
            {
                Console.WriteLine("Recipe Application");
                Console.WriteLine("1. Enter the recipe details");
                Console.WriteLine("2. Display the recipe");
                Console.WriteLine("3. Scale of the recipe");
                Console.WriteLine("4. Reset the quantities");
                Console.WriteLine("5. Clear the recipe");
                Console.WriteLine("6. Exit");
                Console.Write("Select an option: ");

                int option;
                if (!int.TryParse(Console.ReadLine(), out option))
                {
                    Console.WriteLine("Invalid option. Please enter a number.");
                    continue;
                }

                switch (option)
                {
                    case 1:
                        recipe.EnterDetails();
                        break;
                    case 2:
                        recipe.Display();
                        break;
                    case 3:
                        recipe.Scale();
                        break;
                    case 4:
                        recipe.ResetQuantities();
                        break;
                    case 5:
                        recipe.Clear();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid option.");
                        break;
                }
            }
        }
    }

    class Recipe
    {
        private List<Ingredient> Ingredients = new List<Ingredient>();
        private List<string> Steps = new List<string>();

        public void EnterDetails()
        {
            Console.WriteLine("Enter the recipe details:");
            Console.Write("Ingredient name: ");
            string name = Console.ReadLine();
            Console.Write("Quantity: ");
            double quantity;
            if (!double.TryParse(Console.ReadLine(), out quantity))
            {
                Console.WriteLine("Invalid quantity. Please enter a number.");
                return;
            }
            Console.Write("Unit: ");
            string unit = Console.ReadLine();

            Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit });

            Console.WriteLine("Step:");
            Steps.Add(Console.ReadLine());
        }

        public void Display()
        {
            Console.WriteLine("Recipe Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("\nRecipe Steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }

        public void Scale()
        {
            Console.WriteLine("Enter the scaling factor:");
            double factor;
            if (!double.TryParse(Console.ReadLine(), out factor))
            {
                Console.WriteLine("Invalid scaling factor. Please enter a number.");
                return;
            }

            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = 0;
            }
        }

        public void Clear()
        {
            Ingredients.Clear();
            Steps.Clear();
            Console.WriteLine("Recipe cleared.");
        }
    }

    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
    }
}
